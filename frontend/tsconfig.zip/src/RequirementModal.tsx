import { useState } from 'react';
import type { Project, Requirement, RequirementInput, RequirementCategory, RequirementPriority, RequirementStatus } from './types';
import { REQ_CATEGORY_LABEL, REQ_PRIORITY_LABEL, REQ_STATUS_LABEL } from './types';
import './ProjectModal.css';

interface Props {
  initial: Requirement | null;
  projects: Project[];
  defaultProjectId?: number;
  onClose: () => void;
  onSubmit: (input: RequirementInput) => Promise<void>;
}

export default function RequirementModal({ initial, projects, defaultProjectId, onClose, onSubmit }: Props) {
  const [projectId, setProjectId] = useState<number>(initial?.project_id ?? defaultProjectId ?? projects[0]?.id ?? 0);
  const [title, setTitle] = useState(initial?.title ?? '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [category, setCategory] = useState<RequirementCategory>(initial?.category ?? 'functional');
  const [priority, setPriority] = useState<RequirementPriority>(initial?.priority ?? 'medium');
  const [status, setStatus] = useState<RequirementStatus>(initial?.status ?? 'draft');
  const [requester, setRequester] = useState(initial?.requester ?? '');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      setError('요구사항 제목을 입력해주세요.');
      return;
    }
    if (!projectId) {
      setError('프로젝트를 선택해주세요.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      await onSubmit({
        project_id: projectId,
        title: title.trim(),
        description: description.trim(),
        category,
        priority,
        status,
        requester: requester.trim(),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : '저장 중 오류가 발생했습니다.');
      setSubmitting(false);
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <form className="modal-panel" onClick={(e) => e.stopPropagation()} onSubmit={handleSubmit}>
        <div className="modal-header">
          <h2>{initial ? '요구사항 수정' : '새 요구사항'}</h2>
          <button type="button" className="modal-close" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body">
          <label className="field">
            <span>프로젝트 *</span>
            <select value={projectId} onChange={(e) => setProjectId(Number(e.target.value))}>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
          </label>

          <label className="field">
            <span>요구사항 제목 *</span>
            <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="예: 프로젝트 CRUD 기능" autoFocus />
          </label>

          <label className="field">
            <span>설명</span>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={3} placeholder="요구사항에 대한 상세 설명" />
          </label>

          <div className="field-row">
            <label className="field">
              <span>분류</span>
              <select value={category} onChange={(e) => setCategory(e.target.value as RequirementCategory)}>
                {Object.entries(REQ_CATEGORY_LABEL).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </label>

            <label className="field">
              <span>우선순위</span>
              <select value={priority} onChange={(e) => setPriority(e.target.value as RequirementPriority)}>
                {Object.entries(REQ_PRIORITY_LABEL).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </label>
          </div>

          <div className="field-row">
            <label className="field">
              <span>상태</span>
              <select value={status} onChange={(e) => setStatus(e.target.value as RequirementStatus)}>
                {Object.entries(REQ_STATUS_LABEL).map(([value, label]) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </label>

            <label className="field">
              <span>요청자</span>
              <input value={requester} onChange={(e) => setRequester(e.target.value)} placeholder="요청자명" />
            </label>
          </div>

          {error && <div className="field-error">⚠ {error}</div>}
        </div>

        <div className="modal-footer">
          <button type="button" className="btn-ghost" onClick={onClose}>취소</button>
          <button type="submit" className="btn-primary" disabled={submitting}>
            {submitting ? '저장 중...' : initial ? '수정 완료' : '요구사항 등록'}
          </button>
        </div>
      </form>
    </div>
  );
}
